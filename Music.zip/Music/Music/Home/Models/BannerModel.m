//
//  BannerModel.m
//  Music
//
//  Created by 石子涵 on 2020/5/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "BannerModel.h"

@implementation BannerModel

@end
