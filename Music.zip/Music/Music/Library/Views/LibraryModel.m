//
//  LibraryModel.m
//  Music
//
//  Created by 石子涵 on 2020/5/24.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "LibraryModel.h"

@implementation LibraryModel
- (void)setValue:(id)value forUndefinedKey:(nonnull NSString *)key{};

@end
