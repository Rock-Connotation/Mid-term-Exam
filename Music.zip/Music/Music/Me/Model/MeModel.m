//
//  MeModel.m
//  Music
//
//  Created by 石子涵 on 2020/5/24.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "MeModel.h"

@implementation MeModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{};
@end
