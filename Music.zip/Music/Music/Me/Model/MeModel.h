//
//  MeModel.h
//  Music
//
//  Created by 石子涵 on 2020/5/24.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MeModel : NSObject
@property (nonatomic, strong)NSString *followeds, *follows, *nickname, *city, *backgroundUrl;
@end

NS_ASSUME_NONNULL_END
